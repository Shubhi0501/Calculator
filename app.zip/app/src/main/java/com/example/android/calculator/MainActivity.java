package com.example.android.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView input;
    private TextView output;
    private StringBuilder sb1= new StringBuilder();
    
    private Button point;
    private Button button0;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private Button button9;
   
 
    private Button equal;
    private Button delete;
    private Button multiply;
    private Button minus;
    private Button plus;
    private Button division;
    private StringBuilder sb2 = new StringBuilder();
    private ArrayList<String> list1 = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        input = (TextView) findViewById(R.id.input);
        output = (TextView) findViewById(R.id.output);
        button7 = (Button) findViewById(R.id.button7);
        button4 = (Button) findViewById(R.id.button4);
        button1 = (Button) findViewById(R.id.button1);
        point = (Button) findViewById(R.id.point);
        button8 = (Button) findViewById(R.id.button8);
        button5 = (Button) findViewById(R.id.button5);
        button2 = (Button) findViewById(R.id.button2);
        button0 = (Button) findViewById(R.id.button0);
        button9 = (Button) findViewById(R.id.button9);
        button6 = (Button) findViewById(R.id.button6);
        button3 = (Button) findViewById(R.id.button3);
        equal = (Button) findViewById(R.id.equal);
        delete = (Button) findViewById(R.id.delete);
        division = (Button) findViewById(R.id.division);
        multiply = (Button) findViewById(R.id.multiply);
        minus = (Button) findViewById(R.id.minus);
        plus = (Button) findViewById(R.id.plus);


        button7.setOnClickListener( this);
        button4.setOnClickListener(this);
        button1.setOnClickListener(this);
        point.setOnClickListener(this);
        button8.setOnClickListener(this);
        button5.setOnClickListener(this);
        button2.setOnClickListener(this);
        button0.setOnClickListener(this);
        button9.setOnClickListener(this);
        button6.setOnClickListener(this);
        button3.setOnClickListener(this);
        equal.setOnClickListener(this);
        delete.setOnClickListener(this);
        division.setOnClickListener(this);
        multiply.setOnClickListener(this);
        minus.setOnClickListener(this);
        plus.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.equal:

/*
                list1.add(sb2.tostring());
                sb2 = null;
                sb2 = new stringBuilder();

                string result = "";
                try {
                  //  result = string.valueOf(s2.pop());
                    result = calculation();
                    output.setText(result);
                } catch (Exception e) {
                    Log.v("error", e.getMessage());
                    result = "";
                    output.setText("Invalid Input");
                }
                list1.clear();
                sb2 = new stringBuilder(result);
                sb1= new stringBuilder(result);

*/

                if (!sb2.toString().equals("")) {
                    list1.add(sb2.toString());
                }

                if(list1.size()==0){
                    output.setText("0");
                    sb2 = new StringBuilder();
                }

                else if(list1.size()%2 != 0) {
                    Stack<Character> s1 = new Stack<Character>();
                    Queue<String> q1 = new LinkedList<String>();
                    Iterator<String> itr = list1.iterator();
                    while (itr.hasNext()) {
                        String str = itr.next();
                        Log.v("Check this iterator", str);
                        if (str.matches("[0-9]*\\.?[0-9]") || str.trim().length() > 1) {
                            q1.add(str);
                        } else {
                            char c = str.charAt(0);
                            if (s1.isEmpty()) {
                                s1.push(c);
                            } else {
                                if (operator(c) <= operator(s1.peek())) {
                                    String x = "" + s1.pop();
                                    q1.add(x);
                                }
                                s1.push(c);

                            }
                        }
                    }
                    while (!s1.isEmpty()) {
                        String x = "" + s1.pop();
                        q1.add(x);
                    }


                    Stack<Double> s2 = new Stack<Double>();
                    Boolean errorflag = false;
                    while (!q1.isEmpty()) {
                        String y = q1.remove();
                        Log.v("Watch this que", y);
                        if (y.matches("[0-9]*\\\\.?[0-9]") || y.trim().length() > 1) {
                            s2.push(Double.parseDouble(y));
                        } else {

                            double a = s2.pop();
                            double b = s2.pop();

                            double c = 0;
                            if (y.equals("+"))
                                c = a + b;
                            else if (y.equals("-"))
                                c = b - a;
                            else if (y.equals("*"))
                                c = a * b;
                            else if (y.equals("/")) {
                                if (a == 0) {
                                    errorflag = true;
                                    break;
                                }
                                c = b / a;
                            }
                            s2.push(c);
                            Log.v("output", String.valueOf(c));
                        }
                    }

                    Log.v("Watch this stackk", String.valueOf(s2.size()));
                    String result = "";
                    if (errorflag == true) {
                        result = "Invalid Input";
                        output.setText(result);
                        sb2 = new StringBuilder();
                        sb1= new StringBuilder();
                    } else {
                        result = String.valueOf(s2.pop());
                        output.setText(result);
                        sb2 = new StringBuilder();
                        sb1= new StringBuilder();

                    }

                }
                else{
                    output.setText("Invalid Input");
                    sb2 = new StringBuilder();
                    sb1= new StringBuilder();
                }
                list1.clear();

                break;


            case R.id.delete:
                sb1= new StringBuilder();
                sb2 = new StringBuilder();
                output.setText("0");
                break;

            case R.id.plus:
                if(sb2.toString().length() != 0) {
                    list1.add(sb2.toString());
                    list1.add(((Button) v).getText().toString());
                    sb1.append(((Button) v).getText());
                    sb2 = new StringBuilder();
                }
                break;

            case R.id.minus:
                if(sb2.toString().length()==0){
                    sb2.append(((Button) v).getText());
                    sb1.append(((Button) v).getText());
                }
                else{
                    list1.add(sb2.toString());
                    list1.add(((Button) v).getText().toString());
                    sb1.append(((Button) v).getText());
                    sb2 = new StringBuilder();
                }
                break;

            case R.id.multiply:
                if(sb2.toString().length() != 0) {
                    list1.add(sb2.toString());
                    list1.add(((Button) v).getText().toString());
                    sb1.append(((Button) v).getText());
                    sb2 = new StringBuilder();
                }
                break;

            case R.id.division:
                if(sb2.toString().length() != 0) {
                    list1.add(sb2.toString());
                    list1.add(((Button) v).getText().toString());
                    sb1.append(((Button) v).getText());
                    sb2 = new StringBuilder();
                }
                break;

            case R.id.point:
                if(sb2.toString().equals("")){
                    sb2.append(((Button) v).getText());
                    sb1.append(((Button) v).getText());
                }
                else{
                    boolean check = sb2.toString().contains(".");
                    //Character checkDecimal =  sb2.tostring().charAt(sb2.tostring().length()-1);
                    if(!check){
                        sb2.append(((Button) v).getText());
                        sb1.append(((Button) v).getText());
                    }
                }
                break;

            default:
                sb2.append(((Button) v).getText());
                sb1.append(((Button) v).getText());
                System.out.println(Arrays.toString(list1.toArray()));
                break;
        }

        input.setText(sb1.toString());
    }
    /*

    private string calculation(){
       Stack<Double> s1 = new Stack<Double>();
        Iterator<string> itr = list1.iterator();
        char ch = '+';
        while (itr.hasNext()) {
            string str = itr.next();
            if (str.matches("[0-9]*\\.?[0-9]*")) {
                s1.add(Double.parseDouble(str));
            } else {
                ch = str.charAt(0);
            }
        }
        double a = s1.pop();
        double b = s1.pop();
        double c = 0;
        switch (ch){
            case '+':
                c = a+b;
                break;
            case '-':
                c = b - a;
                break;
            case '*':
                c = a*b;
                break;
            case '/':
                if (a == 0)
                    throw new
                            UnsupportedOperationException("Cannot divide by zero");
                c = b / a;
                break;

        }
        string result = string.valueOf(c);
        return result;

    }
*/

    private int operator(char c) {
        switch (c) {
            case '+':
            case '-':
                return 1;

            case '*':
            case '/':
                return 2;
        }
        return -1;
    }

/*
    private string calculation() {

        Stack<Character> s1 = new Stack<Character>();
        Queue<string> q1 = new LinkedList<string>();
        Iterator<string> itr = list1.iterator();
        while (itr.hasNext()) {
            string str = itr.next();
            Log.v("Watch this iterator", str);
            if (str.matches("[0-9]*\\.?[0-9]")) {
                q1.add(str);
            } else {
                char c = str.charAt(0);
                if (s1.isEmpty()) {
                    s1.push(c);
                } else {
                    if (operator(c) <= operator(s1.peek())) {
                        string x = "" + s1.pop();
                        q1.add(x);
                    }
                    s1.push(c);

                }
            }
        }
        while (!s1.isEmpty()) {
            string x = "" + s1.pop();
            q1.add(x);
        }


        Stack<Float> s2 = new Stack<Float>();
        while (!q1.isEmpty()) {
            string y = q1.remove();
            Log.v("Watch this que", y);
            if (y.matches("[0-9]*\\.?[0-9]")) {
                s2.push(Float.parseFloat(y));
            } else {
                float a = s2.pop();
                float b = s2.pop();
                float c = 0;
                if (y.equals("+"))
                    c = a + b;
                else if (y.equals("-"))
                    c = b - a;
                else if (y.equals("*"))
                    c = a * b;
                else if (y.equals("/"))
                    if (a == 0)

                c = b / a;

                s2.push(c);
                Log.v("output", string.valueOf(c));
            }
        }
//                System.out.println("Watch hereeee ===>>>>");
        Log.v("Watch this stackk", string.valueOf(s2.size()));
        string result = string.valueOf(s2.pop());
        return result;

    }
*/
}